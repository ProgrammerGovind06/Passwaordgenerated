package com.app.usercontroller;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.app.repo.UserRepository;

@RestController
public class UserController {
    @Autowired
    private UserRepository userRepository;

    @PostMapping("/createUser")
    public User createUser(@RequestBody User user) {
        // Generate password using JavaScript
        String password = generatePassword(user.getFirstName(), user.getMiddleName(), user.getLastName());

        // Save user data to the database
        user.setPassword(password);
        return userRepository.save(user);
    }

    private String generatePassword(String firstName, String middleName, String lastName) {
        
        String randomDigits = String.format("%03d", new Random().nextInt(1000));
        return firstName.substring(0, 2) + middleName.substring(0, 2) + lastName.substring(0, 2) + randomDigits;
    }
}

